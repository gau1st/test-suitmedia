
$(document).ready(function(){

   $("#burger-nav").on("click", function(){
      $("header nav ul").toggleClass("open");
   });

   //
   // Start Day Night
   //
   /* Declare the variable */
   var $dayNightButton = $(".day-night-button");
   var $body = $("body");
   var $contentContainer = $("#content-container");
   var $navigation = $("nav li a");
   var $burgerNav = $("#burger-nav");
   var $burgerSvg = $(".burger-svg");
   var $finLine = $(".fin .line");
   var $p = $("p");
   var $li = $("li");
   var $h1 = $("h1");
   var $h2 = $("h2");
   var $h3 = $("h3");
   var $h4 = $("h4");
   /* Default mode  */
   var isDay = true;

   /* if cookie say "isNight" then set night mode for default mode */
   if (document.cookie == "isNight") {
      $body.toggleClass("night");
      $dayNightButton.toggleClass("night");
      $contentContainer.toggleClass("night");
      $navigation.toggleClass("night");
      $burgerNav.toggleClass("night");
      $burgerSvg.toggleClass("night");
      $finLine.toggleClass("night");
      $p.toggleClass("night");
      $li.toggleClass("night");
      $h1.toggleClass("night");
      $h2.toggleClass("night");
      isDay = false;
   }

   /* Action button when $dayNightButton clicked */
   $dayNightButton.on("click", function(){
      /* Toggle every element with 'night' class  */
      $body.toggleClass("night");
      $dayNightButton.toggleClass("night");
      $contentContainer.toggleClass("night");
      $navigation.toggleClass("night");
      $burgerNav.toggleClass("night");
      $burgerSvg.toggleClass("night");
      $finLine.toggleClass("night");
      $p.toggleClass("night");
      $li.toggleClass("night");
      $h1.toggleClass("night");
      $h2.toggleClass("night");

      if (isDay) {
         /* Set cookie value to 'isNight' if default mode is day (isDay = True)  */
         document.cookie = "isNight";
         isDay = false;
         $dayNightButton.text("Day Mode");
      } else {
         /* Delete cookie value if default mode is night (isDay = False)  */
         document.cookie = "isNight; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
         isDay = true;
         $dayNightButton.text("Night Mode");
      }
   });
   //
   // End Day Night
   //


});
